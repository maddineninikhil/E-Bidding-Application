App = {
	web3Provider: null,
	contracts: {},
	account: '0x0',
	
	init: async function() {
	
		return await App.initWeb3();
	},

	initWeb3: async function() {
		if (typeof web3 !== 'undefined') {
			// If a web3 instance is already provided by Meta Mask.
			App.web3Provider = web3.currentProvider;
			web3 = new Web3(web3.currentProvider);
		} else {
			// Specify default instance if no web3 instance provided
      			App.web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
      			web3 = new Web3(App.web3Provider);
    		}    
		return App.initContract();
	},

	initContract: function() {
		$.getJSON("Tender.json", function(tender) {
			// Instantiate a new truffle contract from the artifact
			App.contracts.Tender = TruffleContract(tender);
			// Connect provider to interact with contract
			App.contracts.Tender.setProvider(App.web3Provider);
			App.listenForEvents();
			return App.render();
  		});
	},
	
	listenForEvents: function(){
		App.contracts.Tender.deployed().then(function(instance){
			instance.deployTender().watch(function(error, event){
				if(!error){
					console.log("Event Triggered", event);
					$("#show").show();
					$("#show1").html("Tender Deployed Please Close and Refresh ..!!");
				}
			});
			instance.deployedBid().watch(function(error,event){
				if(!error){
					$("#show5").show();
					$("#show5").html("Bid placed..!!");
					App.bid();
				}
			});		
		});
	},

	bid:function(){
		App.contracts.Tender.deployed().then(function(instance){
			instance.bid(Ac).then(function(c){
			});
		});
	},
	render: function() {
		var tenderInstance;
		$("#show").hide();
		$("#show2").hide();
		var acc;
		web3.eth.getAccounts(function(err,res){
			acc = res;
		});
		web3.eth.getCoinbase(function(err, account) {
			if (err === null) {
				App.account = account;
				Ac = account;
				//console.log(window.location.href)
				if(window.location.href=="http://localhost:3000/index.html" || window.location.href=="http://localhost:3000/"){
					if(Ac!="0xa587d944130697760edecae6d74c42663a98065f"){
						window.location.replace("http://localhost:3000/bidorg.html");
					}
				}
				if(window.location.href=="http://localhost:3000/bidorg.html"){
					if(Ac=="0xa587d944130697760edecae6d74c42663a98065f"){
						window.location.replace("http://localhost:3000/index.html");
					}
				}
				$("#pubk").attr("placeholder",App.account);
				$("#accountAddress").html(account);
			}
		});



		App.contracts.Tender.deployed().then(function(instance){
			tenderInstance = instance;
    			return tenderInstance.count();
    		}).then(function(numcount){
    			
       			var results = $("#tenderResults");
			var template;
			results.empty();
			//$("#accountAddress").html("Account: " + numcount);
			//tenderInstance.tender(1).then(function(c){$("#accountAddress").html("Account: " + c[1]);}); 
       			for (var i = 1; i <= numcount; i++) {
           			tenderInstance.tender(i).then(function(c){
               			var id = c[0];
						var name = c[1];
						$("#t1").show();
						$("#warn").hide();
               			template = "<tr><td scope='col' class='text-center' id='i'>"+id+"</td><td scope='col' class='text-center'>"+name+"</td><td scope='col' class='text-center'><button onclick='App.disp("+id+"); return false;' type='button' data-toggle ='modal' data-target='#myModal' class='btn btn-success'>view</button></td></tr>";
               			results.append(template);
						$("#bb2").hide();
						$("#tb1").hide();
       				});
    			}
  		});
    		$('#t1 tr').each(function(){
			if($(this).find('td').length==0){
				$("#t1").hide();
				$("#warn").show();		
			}
		}); 
	},


	
	disp: function(id){
		App.contracts.Tender.deployed().then(function(instance){
			imp =id;
			idt =id;
			//console.log(idt)
			i = instance;
			var lmt;
			i.tender(id).then(function(c){
				lmt  = c[4];
				$("#modal-title").html("Tender details:");
				$("#tenderid").html(c[0].toString());
				$("#tendername").html(c[1]);
				$("#tenderpubk").html(c[3]);
				$("#tenderend").html(new Date(c[2]*1000));
				$("#tenderlimit").html(c[4].toString());
			});
			i.bid(App.account).then(function(r){
				var bid = r[0].toNumber();
				if(r[3]>=lmt && bid==id){
					$("#btn1").hide();
					$("#text1").html("Limit to Bid Exceeded....!!! </br>Wait for Results..!!!");
				}else{
					$("#btn1").show();
					$("#text1").html("");
				}
			});
		});

		App.contracts.Tender.deployed().then(function(instance){				
				//console.log(idt);
				var ins = instance;
			instance.reqBids(idt).then(function(value){
				//Evaluationcode
				if(value){
					$("#btn1").hide();
					
					App.contracts.Tender.deployed().then(function(instance){
						instance.results(idt).then(function(res){
							if(res[0]!=0){
								resadr = res[0];
								resbids = res[1];
								$("#bb").hide();
								$("#tbk11").show();
								$("#tbk1").html(res[1]);
								$("#tbk22").show();
								$("#tbk2").html(res[2]);
								if(Ac == res[1] ){
									$("#text1").html("<h3>Congratulations..!!</h3><h4>Your Bid:"+res[2]+"</h4>");
								}else{
									$("#text1").html("<h3>Best Bid:</h3>Address:"+res[1]+"</br>Bid:"+res[2]);
								}
								if(Ac==res[1]){
									swal({
										icon: "success",
										title:"Congratulations",
        								text: "Your Bid "+res[2]+" is selected!!",
  									});
								}else{
									swal({
										icon: "success",
										title:"Best Bid",
        								text: res[2],
 								 });
							}
							}else{
								$("#text1").html("Tender period Over");
							}
							});
						});
					//
					//
					//
				}
			});
		});
	},
	
	s: function(){
		$("#btn1").hide();
		$("#form1").show();
		idt = $("#i").text();
	},
 	s1: function(){
		$("#bb2").hide();
		$("#tb1").show();
	},
	getPubk: function(){
		var i;
		App.contracts.Tender.deployed().then(function(instance){
			i = instance;
			i.tender(idt).then(function(c){
				i = c[3];
			});
		});
		return i;
	},	

	
	deployTender: function() {
		var name = $("#Name").val();
		var deadline = $("#End").val();
    		var pubk = App.account;
    		var limit = $("#sel").val();
    		//$("#accountAddress").html("Account: " + deadline);
    		App.contracts.Tender.deployed().then(function(instance){
         		instance.requestForTender(name, deadline, pubk, limit);
			$("#show").show();
			$("#show1").html("Wait Tender will be Deployed After MetaMask Confirmation ..!!");
			
 		 });
  	},
	
	evaluateResult: function(){
		var ar =[];
		var ky=[];
		$("#bb").hide();
		$("#bb2").show();
		$("#tb2").hide();
		var results = $("#tenderResults2");
		results.empty();
									
		 App.contracts.Tender.deployed().then(function(instance){				
				//console.log(idt);
				var ins = instance;
				instance.reqBids(idt).then(function(value){
				//Evaluationcode
				if(!value){
					$("#res").html("<b>Wait till Deadline..!!</b>");
					$("#bb2").hide();
					$("#tbk").hide();
					$("#tbk1").hide();
					$("#tbk2").hide();
				}else{
					$("#res").html("<b>Fetched Data..!!</b>");
					$("#bb2").show();
					$("#tbk").hide();
					$("#tbk1").hide();
					$("#tbk2").hide();
					instance.getBidAddr().then(function(value){
											
						for(var i =0 ; i<value.length;i++){
							//console.log(value[i])
							instance.bid(value[i]).then(function(c){
								if(c[0]==idt && c[3] ==true){
									ar.push(c[1]);
			 						ky.push(c[2]);	
									//console.log(ar);	
									//console.log(ky);
									var i1;	
									var template = "<tr><td scope='col' class='text-center' id='i'>"+c[5]+"</td><td scope='col' class='text-center'>"+c[1]+"</td><td scope='col' class='text-center'>"+c[2]+"</td></tr>";
									results.append(template);
									$("#tb2").hide();
								
								}else{
									return;
								}
							});
						
						}
					
					});
				}
				});
			ins.tender(idt).then(function(c){return c[3];}).then(function(r){$("#tbk").html(r);});
		});		
	},

	uploadRes: function(){
		$("bb3").hide();
		$("#tbk1").show();
		$("#tbk11").show();
		
		$("#tbk2").show();
		$("#tbk22").show();
		var resaddr = $("#tbk1").text();
		var resbid = $("#tbk2").text();
		App.contracts.Tender.deployed().then(function(instance){
			instance.evaluationResult(idt, resaddr, resbid);
		});	
	},

	deployBid: function(){
		var data = $("#show3").text();
		var bkey = $("#show4").text();
		//console.log(data);
		//console.log(bkey);
		var count;
		App.contracts.Tender.deployed().then(function(instance){
			i = instance;
			i.bid(Ac).then(function(c){
				count=c[3];
			});
		});
		// provider = new Web3.providers.HttpProviders('http://localhost:8545');
		//var	web3 = new Web3(provider)
		var hex = '';
		for (var i =0; i<data.length;i++){
			hex +=''+data.charCodeAt(i).toString(16); 
		}
		let web3 = new Web3(new Web3.providers.HttpProvider("http://127.0.0.1:8545"));		
		hex = '0x'+hex;
		var acc =  Ac;
		let signature = web3.eth.sign(acc,hex);
		//console.log(signature);
		let fixed_msg = `\x19Ethereum Signed Message:\n${data.length}${data}`;
   	 	let fixed_msg_sha = web3.sha3(fixed_msg);
		//console.log(fixed_msg_sha);
		//placeBid function
		//console.log(fixed_msg_sha);
		//console.log(signature)
		//console.log(idt)
		App.contracts.Tender.deployed().then(function(instance){
			instance.placeBid(imp, data, bkey, fixed_msg_sha, signature);
			//instance.validBid(idt, fixed_msg_sha, signature);

		});
	}
};


$(function() {
	$("#form1").hide();
	$("#tb2").hide();
	$("#bb3").hide();
	$("#tbk11").hide();
	$("#tbk22").hide();
	$(window).load(function() {
		var Ac;
		var imp;
		var idt;
		var epubk;
    	App.init();
  	});
});
